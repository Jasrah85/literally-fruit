import type { Metadata, Viewport } from "next";
import "@fontsource-variable/bodoni-moda/opsz.css";
import "@fontsource-variable/hanken-grotesk";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://literallyfruit.com"),
  title: "Literally Fruit | Small-batch fruit tea, coming soon",
  description:
    "Loose-leaf tea with real fruit, sweetened with stevia instead of sugar. Blended by hand in small batches in Southwest Ohio.",
  // Placeholder period: keep search engines out until the Phase 0 site launches.
  // Remove this (and app/robots.ts) at launch.
  robots: { index: false, follow: false },
};

export const viewport: Viewport = {
  themeColor: "#1b1310",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className="h-full">
      <body className="min-h-full bg-steep text-leaf">{children}</body>
    </html>
  );
}
